<?php include 'includes/header.php'; ?>
<div class="ttm-page-title-row">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="title-box ttm-textcolor-white">
          <div class="page-title-heading">
            <h1 class="title">Career</h1>
          </div><!-- /.page-title-captions -->
          <div class="breadcrumb-wrapper">
            <span>
              &nbsp;&nbsp;Home</a>
            </span>
            <span class="ttm-bread-sep">&nbsp; | &nbsp;</span>
            <span>Career</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container my-4">
  <div class="row gy-2">
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Ground Staff</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Ground Staff</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Airline Ticket Agent</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Airline Ticket Agent</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Customer Relationship Manager</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Customer Relationship Manager</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Travel and Tour Operator/Agent </h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Travel and Tour Operator/Agent </h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Hotel Manager</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Hotel Manager</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Front Office Manager</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Front Office Manager</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Chef</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Chef</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">
              Housekeeping Manager</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">
              Housekeeping Manager</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
    <div class="col-sm-3 d-flex justify-content-center">

      <div class="flip-card">
        <div class="flip-card-inner ">
          <div class="flip-card-front d-flex align-items-center justify-content-center">
            <h1 style="font-size: 18px;">Floor Supervisors</h1>
          </div>
          <div class="flip-card-back d-flex flex-column justify-content-center">
            <h1 style="font-size: 18px;">Floor Supervisors</h1>
            <a href="apply-now.html"><button class="btn btn-danger mx-auto">Apply Here</button></a>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>