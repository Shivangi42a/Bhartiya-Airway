   <?php include 'includes/header.php'; ?>

   <!-- page-title -->
   <div class="ttm-page-title-row">
     <div class="container">
       <div class="row">
         <div class="col-md-12">
           <div class="title-box ttm-textcolor-white">
             <div class="page-title-heading">
               <h1 class="title">About Us</h1>
             </div>
             <div class="breadcrumb-wrapper">
               <span>
                 &nbsp;&nbsp;Home
               </span>
               <span class="ttm-bread-sep">&nbsp; | &nbsp;</span>
               <span>About Us </span>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>

   <section>
     <div class="container my-5">
       <h4 class="text-center" style="font-weight:700;">BHARTIYA AIRWAYS</h4>
       <div class="row">
         <div class="col-md-12">

           <p class="text-justify mt-3">Back in 2019, With the vision of Mr. Bhagvanta Singh,
             Bhartiya Airways started its journey.

             The success of Bhartiya Airways over the years has made us one of the leading platforms when it comes to travel and flight booking.

             Where users meet the expectations of their dream destination at very affordable pricing with many offers and discounts,
             And this is our sole dedication to making travel affordable even to the lower middle class,

             From Leh to Kanyakumari or from Rann of kutch to Dong,
             Our holidays packages will expand to every part of India and internationally.

             The thing that made us stand apart from the crowd is that we have our travel guides in every major destination, who is responsible for your travel to be more comfortable and hassle-free

             Users who plan their dream destination with us always opt for us for their further travel plans because of our user-centric approach, where we don't let any room for complaint in the minds of our dear customers.

             And we are not just stopping here; Our future goal is to launch our airlines by 2025. It's a dream for which every member of the Bhartiya Airways family is working tirelessly. So stay tuned on the journey of Bhartiya Airways.

           </p>

         </div>
       </div>
     </div>


   </section>



   <?php include 'includes/footer.php'; ?>