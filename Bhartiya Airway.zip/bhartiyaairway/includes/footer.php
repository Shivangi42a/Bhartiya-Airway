<div class="backgound-color-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h3 class="widget">About Bhartiya Airways</h3>
                <p>
                    Bhartiya Airways was established to excel in the sector of airways and management services. Back in 2019, With the vision of founder Bhagwanta Singh, Bhartiya Airways started its journey. And in the same year, with the Government of India, we registered ourselves under MCA(Ministry of Corporate Affairs).
                </p>
            </div>

            <div class="col-md-4 d-flex align-items-center flex-column">
                <h3 class="widget-title">Quick Links</h3>
                <ul id="menu-footer-services" class="footer-services paddingtop">
                    <li><a href="contact-us.php"><i class="la la-angle-double-right"></i>Contact us</a></li>
                    <li><a href="career.php"><i class="las la-angle-double-right"></i>Career</a></li>
                    <li><a href="about.php"><i class="las la-angle-double-right"></i>About Us</a></li>
                </ul>
            </div>

            <div class="col-md-4">
                <h3 class="widget-title">Quick Enquiry</h3>
                <div class="textwidget widget-text">
                    <ul class="ttm-our-location-list">
                        <li><i class="fa fa-envelope-o"></i><a href="mailto:jobs@bhartiyaairways.com">Jobs: jobs@bhartiyaairways.com</a></li>
                        <li><i class="fa fa-envelope-o"></i><a href="mailto:hr@bhartiyaairways.com">HR: hr@bhartiyaairways.com</a></li>
                        <li><i class="fa fa-envelope-o"></i><a href="mailto:info@bhartiyaairways.com">Business: info@bhartiyaairways.com</a></li>
                        <li><i class="fa fa-envelope-o"></i><a href="mailto:career@bhartiyaairways.com">Career: career@bhartiyaairways.com</a></li>

                    </ul>
                </div>

            </div>


        </div>

    </div>
</div>
<div class="fn-footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h6 style="color: white;font-size: 11px; text-align: center;">Copyright © 2021 SRBS BHARTIYA AIRWAYS SERVICES PRIVATE LIMITED</h6>
            </div>
        </div>
    </div>
</div>



</div>
<script>



</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>