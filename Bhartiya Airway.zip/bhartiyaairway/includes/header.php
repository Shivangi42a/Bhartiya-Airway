<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <title>Bhartiya airways</title>
</head>

<body>
  <div class="ttm-topbar-wrapper ttm-bgcolor-darkgrey d-lg-block d-none ttm-textcolor-white clearfix">
    <div class="container">
      <div class="ttm-topbar-content">
        <ul class="top-contact ttm-highlight-left text-left" style="background-color:#fc0101!important;">
          <li><i class="fab fa-clock-o"></i><strong>Open Hours:</strong> Mon - Sat 9.00 AM - 06.00 PM</li>
        </ul>
        <div class="topbar-right text-end">
          <ul class="top-contact">
            <li><i class="fab fa-envelope-o"></i><a href="mailto:hr@bhartiyaairways.com">hr@bhartiyaairways.com</a></li>
            <li><a href="tel:9204044044"><i class="fa fa-phone"></i>+91-9204044044</a> </li>
          </ul>
          <div class="ttm-social-links-wrapper list-inline">
            <ul class="social-icons" style="list-style-type: none;">
              <li><a href=""><i class="fab fa-facebook"></i></a>
              </li>
              <li><a href="https://twitter.com/BhartiyaAirways"><i class="fab fa-twitter"></i></a>
              </li>
              <li><a href="#"><i class="fab fa-instagram"></i></a>
              </li>
              <li><a href="https://in.linkedin.com/company/bhartiya-airways"><i class="fab fa-linkedin"></i></a>
              </li>
              <li><a href="https://www.youtube.com/channel/UCu1F4UVw_jVkmkVAQur6HVg"><i class="fab fa-youtube"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>


  <nav class="navbar navbar-expand-lg navbar-light  p-0">
    <div class="container">
      <a class="navbar-brand p-0" href="#"> <a href="index.php"><img src="images/logo.webp" class="logo " alt="..."></a></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto text-capitalize">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="career.php">Career</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact-us.php">Contact us</a>
          </li>
        </ul>
      </div>
      <div class="ttm-rt-contact">
        <!-- header-icons -->
        <div class="ttm-header-icons">
          <div class="ttm-header-icon ttm-header">
            <a href="apply-now.html" class="apply-btn rounded">Apply Now</a>
          </div>
        </div><!-- header-icons end -->
      </div>
    </div>
  </nav>