<?php include 'includes/header.php'; ?>

<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>

  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/airways-job.webp" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <!-- <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p> -->
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/airway-job-3.webp" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <!-- <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p> -->
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/airways-job-2.webp" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <!-- <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p> -->
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/bhartiya-air.webp" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <!-- <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p> -->
      </div>
    </div>
  </div>

</div>



<section class="mt-5 mb-5">
  <div class="container">
    <div class="row">
      <div class="col-md-7">

        <h3 class="text-color-h"> <strong> Career Opportunities with Bhartiya Airways </strong> </h3>
        <p class="text-justify"> Do you want a secure and high-paying job in the airport, hospitality and travel industry? You may not know how to get the golden chance to get recruited in the airport, travel and hospitality industry. Bhartiya Airways is forever devoted to the young brigade of India and helps in career establishment in the airways. The travel, hospitality and airport job will give you the benefit of traveling worldwide. </p>
        <p class="text-justify"> At Bhartiya Airways, we carry on here to hire capable candidates for different profiles, including ground staff, Customer Relationship Manager, airline ticket agents Hotel Manager, Travel and Tour Operator/Agent, Floor Supervisors, Front Office Manager, Housekeeping Manager, Chef and many more. Candidates are free to apply for airline ticket agents and ground staff jobs here.

          The minimum qualification to apply for this job is successful 10th pass certification from any recognized education board in India. We also offer training for such profiles, and undergraduates can use it here to make an excellent career in the airport, hospitality, and travel industry.
        </p>
      </div>
      <div class="col-md-5 mt-3 ">
        <img class="w-100 img-thumbnail" src="images/interview-guidelines.webp" alt="Bhartiya Airways">
      </div>


    </div>

  </div>




</section>


<section class="mt-3 mb-3 ttm-bgcolor-darkgrey-light-blue pt-5 pb-5">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h6><strong> We provide training and recruitment for the following jobs:- </strong> </h6>
      </div>
      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Ground Staff </strong></h2>

        <p class="text-justify"> If you want to make a career as a Ground staff, you should know everything about this profile. Ground staff job contains various complications and responsibilities. They have to be attentive and utilize convenient methods to bring solutions for unpredictable questions of passengers. The ground staff is mainly accountable for ensuring the security and ease of the passengers in the airport. </p>


      </div>
      <div class="col-md-6">
        <img src="images/ground-staff.webp">


      </div>


    </div>

  </div>




</section>

<section class="mt-3 mb-3  pt-5 pb-5">
  <div class="container">
    <div class="row">

      <div class="col-md-6">
        <img src="images/airline-ticket-agent.webp">

      </div>


      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Airline Ticket Agent</strong></h2>

        <p class="text-justify">The airline ticketing agent is liable for making flight ticket bookings and managing reservations for passengers. The concerned person communicates, responds, and solves the problems of customers. These questions may include ticket price, reservation, flight schedule, seat accessibility, and many more.

          They also manage crucial functions, including payment collection, customer data accumulation, verification, etc. Airline ticketing agents can also work similarly to ground staff on airports. They need to be ready and flexible to work long hours and different shifts.
        </p>

      </div>


    </div>


  </div>

</section>
<section class="mt-3 mb-3 ttm-bgcolor-darkgrey-light-blue pt-5 pb-5">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
      </div>
      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Customer Relationship Manager </strong></h2>

        <p class="text-justify">The customer relationship manager in the hospitality and airways industry is responsible for interacting with passengers and providing them information about their hotel booking/flight ticket booking. We have training modules and curricula which incorporate the core principle of customer handling. The core values may include discipline, sophisticated behavior, patience, reliability, integrity, and customer friendly. </p>


      </div>

      <div class="col-md-6">
        <img src="images/customer-relationship-manager .webp">

      </div>
    </div>

  </div>




</section>

<section class="mt-3 mb-3  pt-5 pb-5">
  <div class="container">
    <div class="row">

      <div class="col-md-6">

        <img src="images/travel-and-tour-operator-agent .webp">
      </div>


      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Travel and Tour Operator/Agent </strong></h2>

        <p class="text-justify">Travel and tour operator/agent is the most crucial individual in the hospitality and travel industry. Travel agents always help people find the best method of transportation, hotel booking facilities, rental cars, and flight booking, rescheduling, or canceling of bookings. They also help claim a refund in case of ticket or hotel booking cancellation. </p>

      </div>


    </div>


  </div>

</section>


<section class="mt-3 mb-3 ttm-bgcolor-darkgrey-light-blue  pt-5 pb-5">
  <div class="container">
    <div class="row">




      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Hotel Manager</strong></h2>

        <p class="text-justify">The hotel manager is a core administrator of a hotel. He needs to fulfill the duty to preserve the service protocols hospitality guidelines and offer amenities to the guests. A hotel manager manages the operation of the housekeeping section; makes sure that fresh and delicious meals are provided for guests. He also makes sure that all staff working in the hotel does their work with complete professionalism and handles a guest with all necessary care. </p>

      </div>
      <div class="col-md-6">
        <img src="images/hotel-manager.webp">

      </div>

    </div>


  </div>

</section>




<section class="mt-3 mb-3   pt-5 pb-5">
  <div class="container">
    <div class="row">
      <div class="col-md-6">

        <img src="images/front-office-manager.webp">
      </div>
      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Front Office Manager</strong></h2>

        <p class="text-justify">Individuals with front office managers administrate the task of receptionists, reservation assistants, data representatives, and other faculty like the custodian and the chime kid. Front office managers are additionally answerable for guaranteeing that guest gets comfortable accommodation and meals as per their demand. Moreover, they organize things between the housekeeping section, beverage department, and many other departments of the hotels. People interested in this post can get proper training and hospitality management courses in Bhartiya Airways. </p>

      </div>

    </div>


  </div>

</section>

<section class="mt-3 mb-3 ttm-bgcolor-darkgrey-light-blue  pt-5 pb-5">
  <div class="container">
    <div class="row">




      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Chef</strong></h2>

        <p class="text-justify">Chef is liable for getting ready dinners, dealing with the kitchen spending plan, mentoring the kitchen crew, requesting supplies, arranging menus, implementing wellbeing and security guidelines, and protecting meal freshness. Culinary specialists are typically the primary individuals to reach the office and handle things, right in the frontline. Bhartiya Airways has multiple courses in hotel management and tourism. </p>

      </div>
      <div class="col-md-6">

        <img src="images/chef.webp">
      </div>

    </div>


  </div>

</section>

<section class="mt-3 mb-3  pt-5 pb-5">
  <div class="container">
    <div class="row">





      <div class="col-md-6">
        <img src="images/housekeeping-manager.webp">

      </div>
      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Housekeeping Manager</strong></h2>

        <p class="text-justify">A housekeeping manager is likewise answerable for mentoring, making lists, and managing chores of housekeepers alongside suitable requesting for cleaning services. The housekeeping manager oversees the housekeepers, cleaners, and other staff work. They are liable for guaranteeing that the whole inn premises, which incorporate the visitor rooms, meeting rooms, dining rooms, and meeting rooms, are perfect and kept up with.</p>
      </div>
    </div>


  </div>

</section>


<section class="mt-3 ttm-bgcolor-darkgrey-light-blue pt-5 pb-5">
  <div class="container">
    <div class="row">


      <div class="col-md-6 d-flex justify-content-center flex-column">
        <h2 class="text-color-font"> <strong>Floor Supervisors</strong></h2>

        <p class="text-justify">Floor supervisors are the spectator that keeps and maintain everything in a precise. They ensure that each suite, room, management, and facility is up to the mark. They coordinate and work personally with housekeeping boys, maids, and more. </p>
      </div>


      <div class="col-md-6">
        <img src="images/floor-supervisors.webp">


      </div>

    </div>


  </div>

</section>

<?php include 'includes/footer.php'; ?>